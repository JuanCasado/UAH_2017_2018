#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

char LeerCaracter (int fd, int posicion);
