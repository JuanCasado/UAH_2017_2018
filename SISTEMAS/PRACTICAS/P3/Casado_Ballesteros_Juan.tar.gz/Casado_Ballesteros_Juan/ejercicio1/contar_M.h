#include <unistd.h>
#include <sys/mman.h>

int ContarCaracteres (int fd, char caracter);
