--------------------------------------------------------------
README
--------------------------------------------------------------

Cuando la gasolinera se inicia lo hace en el estado de PAUSA
para que la simulación comience es necesario darle al botón de
inicio en la interface textual o hacer click sobre la barrera 
en la interface gráfica.

Esta decisión es propia y no tiene una razón justificada, con
esto me refiero a que el programa funcionaría sin problemas de
hacerse de otra forma.

                                       Juan Casado Ballesteros
--------------------------------------------------------------
